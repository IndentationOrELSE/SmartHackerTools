# SmartHackerTools
some smart tools 
